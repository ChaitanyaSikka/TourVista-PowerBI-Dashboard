<!-- ========================================================= -->
<!--                     TOURVISTA README                       -->
<!-- ========================================================= -->

<h1 align="center">
🌍 TourVista
</h1>

<h3 align="center">
Interactive Tourism Analytics Dashboard using Power BI
</h3>

<p align="center">

<img src="https://img.shields.io/badge/Power%20BI-Dashboard-F2C811?style=for-the-badge&logo=powerbi&logoColor=black">

<img src="https://img.shields.io/badge/DAX-Analytics-blue?style=for-the-badge">

<img src="https://img.shields.io/badge/Power%20Query-ETL-success?style=for-the-badge">

<img src="https://img.shields.io/badge/Data%20Visualization-Business%20Intelligence-orange?style=for-the-badge">

<img src="https://img.shields.io/badge/Status-Completed-brightgreen?style=for-the-badge">

</p>

---

# 📌 Project Overview

TourVista is an interactive Business Intelligence dashboard developed using Microsoft Power BI to analyze tourism performance across different Indian states.

The dashboard transforms raw tourism data into meaningful insights through dynamic reports, interactive filtering, advanced DAX calculations, and professional visualizations.

This project helps users monitor tourism growth, analyze revenue trends, compare state performance, evaluate tourism quality, and identify key business insights for better decision-making.

---

# 🎯 Problem Statement

Tourism data often contains thousands of records, making it difficult to identify trends and compare state-wise performance efficiently.

The objective of this project is to design a centralized Power BI dashboard that enables users to:

✔ Monitor tourism growth

✔ Compare domestic and foreign tourists

✔ Analyze tourism revenue

✔ Evaluate tourism quality

✔ Track occupancy rates

✔ Identify top-performing states

✔ Support data-driven decision making

---

# 🎯 Objectives

The primary objectives of this dashboard are:

- Analyze tourism performance across India.
- Monitor monthly tourist arrivals.
- Compare domestic and foreign visitors.
- Evaluate tourism revenue generation.
- Analyze tourism quality indicators.
- Compare occupancy rates among states.
- Identify high-performing tourism destinations.
- Generate business insights using interactive dashboards.

---

# 🚀 Dashboard Features

✅ Interactive Navigation

✅ Dynamic KPI Cards

✅ Interactive Slicers

✅ Cross Filtering

✅ Advanced DAX Measures

✅ Business Intelligence Reporting

✅ State-wise Analysis

✅ Revenue Analysis

✅ Tourism Quality Monitoring

✅ Advanced Insights Dashboard

---

# 🛠 Tools & Technologies

| Category | Technology |
|----------|------------|
| Dashboard | Microsoft Power BI |
| Data Cleaning | Power Query |
| Data Modeling | Power BI Model |
| Calculations | DAX |
| Visualization | Power BI Charts |
| Dataset | Tourism Dataset |

---

# 📂 Dataset Information

The dashboard is built using a tourism dataset containing multiple performance indicators.

### Dataset includes:

- State
- Year
- Quarter
- Month
- Domestic Tourists
- Foreign Tourists
- Total Tourists
- Tourism Revenue
- Revenue Per Tourist
- Marketing Spend
- Occupancy Rate
- Average Stay
- Safety Index
- Cleanliness Index
- Transport Index

---

# 📈 Dashboard Architecture

```

Raw Dataset

↓

Power Query

↓

Data Cleaning

↓

Data Modeling

↓

DAX Measures

↓

Interactive Dashboard

↓

Business Insights

```

---


# 📚 Dashboard Pages

The dashboard consists of **6 Interactive Pages** designed for different analytical purposes.

| Page | Description |
|-------|------------|
| 🏠 Overview | High-level tourism summary |
| 👥 Tourist Analysis | Tourist behavior analysis |
| 💰 Revenue Analysis | Revenue performance |
| 📍 State Analysis | State comparison |
| ⭐ Tourism Quality | Quality indicators |
| 💡 Insights | Advanced business insights |

---

# 📊 Page 1 — Overview

The Overview page provides a complete summary of the tourism sector through key business indicators.

It enables users to quickly understand tourism performance without navigating through multiple reports.

### KPIs

- Total Tourists
- Total Domestic Tourists
- Total Foreign Tourists
- Total Revenue
- Average Stay
- Average Occupancy

### Visualizations

- Monthly Tourist Trend
- Monthly Revenue Trend
- Revenue by State
- Occupancy Gauge
- Tourist Composition

### Dashboard Preview


![Overview](Screenshots/overview.png)

---

# 📊 Page 2 — Tourist Analysis

The Tourist Analysis page provides detailed insights into tourist arrivals across India.

Users can compare domestic and foreign visitors while identifying the most visited states and seasonal trends.

### KPIs

- Total Tourists
- Domestic Tourists
- Foreign Tourists
- Foreign Tourist Share

### Visualizations

- Monthly Tourist Arrivals
- Tourist Composition
- Top Tourist States
- Treemap
- State Distribution

### Dashboard Preview


![Tourist Analysis](Screenshots/tourist_analysis.png)
---

# 📊 Page 3 — Revenue Analysis

The Revenue Analysis page focuses on tourism revenue generation across states.

Users can compare revenue performance, evaluate marketing effectiveness, and identify the major contributors to tourism income.

### KPIs

- Total Revenue
- Revenue Per Tourist
- Marketing Spend
- Foreign Share %

### Visualizations

- Monthly Revenue Trend
- Revenue Contribution
- Top Revenue States
- Marketing Spend vs Revenue

### Dashboard Preview


![Revenue Analysis](Screenshots/revenue_analysis.png)


---
# 📊 Page 4 — State Analysis

The **State Analysis** page provides a comparative analysis of tourism performance across different Indian states. It enables users to evaluate occupancy rates, tourist arrivals, safety indicators, and revenue generation at the state level.

### KPIs

- Total States
- Highest Revenue State
- Average Occupancy Rate
- Average Safety Index

### Visualizations

- Top States by Occupancy
- Revenue vs Tourist Analysis
- State Performance Table
- Safety Comparison

### Dashboard Preview


![State Analysis](Screenshots/state_analysis.png)


---

# ⭐ Page 5 — Tourism Quality Analysis

The **Tourism Quality Analysis** page evaluates the quality of tourism infrastructure by comparing safety, cleanliness, transportation facilities, and occupancy rates across states.

This page helps identify which states provide the best tourism experience.

### KPIs

- Average Safety Index
- Average Cleanliness Index
- Average Transport Index
- Average Occupancy Rate

### Visualizations

- Quality Score by State
- Safety vs Cleanliness
- Transport Index by State
- Monthly Tourism Quality Trend

### Dashboard Preview


![Tourism Quyalit](Screenshots/tourism_quality.png)


---

# 💡 Page 6 — Insights Dashboard

The **Insights Dashboard** summarizes the most valuable business insights generated from the entire report. It enables users to quickly identify top-performing states, monthly trends, and revenue changes through advanced Power BI visuals.

### KPIs

- Highest Revenue State
- Revenue per Tourist
- Best Quality State
- Highest Tourist Month

### Visualizations

- Ribbon Chart
- Waterfall Chart
- KPI Insight Cards

### Dashboard Preview


![Insights](Screenshots/insights.png)


---

# 📈 Key Business Insights

- Tamil Nadu generated the highest tourism revenue.
- Domestic tourists contribute significantly more than foreign tourists.
- Tourism revenue varies across different months and states.
- States with higher occupancy generally generate higher tourism revenue.
- Safety, cleanliness, and transportation significantly influence tourism quality.
- Interactive filtering enables detailed state-wise analysis.

---

# 📊 DAX Measures Used

The dashboard includes several custom DAX measures to generate business insights.

Some of the important measures are:

- Total Tourists
- Total Domestic Tourists
- Total Foreign Tourists
- Total Revenue
- Revenue per Tourist
- Average Occupancy Rate
- Foreign Share %
- Tourist Value
- Highest Revenue State
- Best Quality State
- Highest Tourist Month

---

# 📁 Project Structure

```text
TourVista-PowerBI-Dashboard
│
├── TourVista.pbix
├── tourism_data.csv
├── README.md
├── LICENSE
│
├── Screenshots
│   ├── overview.png
│   ├── tourist-analysis.png
│   ├── revenue-analysis.png
│   ├── state-analysis.png
│   ├── tourism-quality.png
│   └── insights.png
```

---
---

# 🚀 Installation Guide

Follow the steps below to explore the dashboard on your local machine.

### Prerequisites

- Microsoft Power BI Desktop
- Git (Optional)
- Tourism Dataset (Included)

### Steps

1. Clone this repository

```bash
git clone https://github.com/jaybhakat07/TourVista-PowerBI-Dashboard.git
```

2. Open the project folder.

3. Launch **Microsoft Power BI Desktop**.

4. Open the **TourVista.pbix** file.

5. If required, refresh the dataset from **Home → Refresh**.

6. Explore the interactive dashboard using slicers and filters.

---

# 📖 How to Use

The dashboard is fully interactive.

### Use the slicers to filter data by:

- Year
- Quarter
- Month
- State

### Navigate through different dashboard pages:

- 🏠 Overview
- 👥 Tourist Analysis
- 💰 Revenue Analysis
- 📍 State Analysis
- ⭐ Tourism Quality Analysis
- 💡 Insights Dashboard

Clicking on charts automatically cross-filters the remaining visuals, providing deeper analytical insights.

---

# 🎯 Skills Demonstrated

This project demonstrates practical knowledge of:

- Power BI Dashboard Development
- Data Cleaning using Power Query
- Data Modeling
- DAX Calculations
- KPI Development
- Interactive Report Design
- Business Intelligence
- Data Visualization
- Dashboard Navigation
- Analytical Thinking

---

# 📌 Key Features

✔ Interactive Dashboard Navigation

✔ Dynamic KPI Cards

✔ Advanced DAX Measures

✔ Interactive Slicers

✔ Cross Filtering

✔ State-wise Analysis

✔ Revenue Analytics

✔ Tourism Quality Monitoring

✔ Business Insights

✔ Responsive Dashboard Design

---

# 📈 Future Improvements

This project can be further enhanced by adding:

- AI-based Tourism Forecasting
- Real-Time Data Integration
- Drill-Through Reports
- Mobile Optimized Dashboard
- Geographic Heat Maps
- Predictive Analytics
- Natural Language Q&A
- Live API Integration

---

# 📸 Dashboard Gallery

## 🏠 Overview

![Overview](Screenshots/overview.png)

---

## 👥 Tourist Analysis

![Tourist Analysis](Screenshots/tourist_analysis.png)

---

## 💰 Revenue Analysis

![Revenue Analysis](Screenshots/revenue_analysis.png)

---

## 📍 State Analysis

![State Analysis](Screenshots/state_analysis.png)

---

## ⭐ Tourism Quality Analysis

![Tourism Quality](Screenshots/tourism_quality.png)

---

## 💡 Insights Dashboard

![Insights](Screenshots/insights.png)

---

# 👨‍💻 Author

## Jay Bhakat

**B.Tech Computer Science (Data Science)**

Passionate about Data Analytics, Business Intelligence, Data Visualization, and Dashboard Development.

### Connect with Me

- GitHub: https://github.com/jaybhakat07
- LinkedIn: (https://www.linkedin.com/in/jay-bhakat07/)
---

# ⭐ If you found this project helpful

Please consider giving this repository a **Star ⭐**.

It motivates me to build more Data Analytics and Power BI projects.

---

# 📄 License

This project is licensed under the **MIT License**.

You are free to use this project for learning and educational purposes.

---

<p align="center">

### ⭐ Thank you for visiting this repository! ⭐

Made with ❤️ using Microsoft Power BI

</p>